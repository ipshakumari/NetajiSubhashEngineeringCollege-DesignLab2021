const data = {
  products: [
    {
      id: '1',
      name: 'Laptop',
      price: 1400,
      // image: 'https://picsum.photos/id/180/2400/1600',
      image: 'https://picsum.photos/id/180/3008/2008',
    },
    {
      id: '2',
      name: 'Car',
      price: 2400,
      // image: 'https://picsum.photos/id/111/4400/2656',
      image: 'https://picsum.photos/id/111/3008/2008',
    },
    {
      id: '3',
      name: 'Shoes',
      price: 1000,
      image: 'https://picsum.photos/id/21/3008/2008',
    },
    {
      id: '4',
      name: 'Camera',
      price: 1200,
      image: 'https://picsum.photos/id/250/3008/2008',
    },
  ],
};
export default data;
