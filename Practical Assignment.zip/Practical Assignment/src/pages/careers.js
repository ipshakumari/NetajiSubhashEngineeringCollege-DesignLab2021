import React from 'react';

const Careers = () => {
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'Right',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Careers</h1>

    {/* <h4>Anyone who is really, really good at anything has a place at Agnikul.</h4> */}
	</div>
);
};

export default Careers;








