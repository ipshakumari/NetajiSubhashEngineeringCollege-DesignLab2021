import React from 'react';

const Engineering = () => {
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'Right',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Engineering</h1>
    {/* <h4>Engineering is at the heart of what we want to deliver to our customers. You can read about some of our hardware / software here.</h4> */}
	</div>
);
};

export default Engineering;
