import React from 'react';

const Launch = () => {
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'Right',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Book your launch</h1>
	</div>
);
};

export default Launch;