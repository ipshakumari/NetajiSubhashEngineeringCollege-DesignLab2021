import React from 'react';

const Products = () => {
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'Right',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>A CONFIGURABLE DESIGN</h1>
	</div>
);
};

export default Products;
