import React from 'react';

const Team = () => {
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'Right',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Meet Agnikul's crew</h1>

    {/* <h4>The human engines driving Agnikul are our extremely dedicated and hardworking crew. We are a fairly young team of 60 people, guided by an extremely accomplished set of advisors - we constantly strive to balance experience with passion.</h4> */}
    
	</div>
);
};

export default Team;
